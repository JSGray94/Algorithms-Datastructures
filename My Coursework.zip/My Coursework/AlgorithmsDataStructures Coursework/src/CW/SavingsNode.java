/*
 * Created by: Jordan Stephano Gray
 * University: Edinburgh Napier University
 * Matric: 40087220
 * Year: 3
 * Module: Algorithms and Data Structures
 * Email: graybostephano@gmail.com
 * Project Purpose: Assign with task of implementing 
 * an algorithm to solve vehicle routing problems.
 * Algorithm Used: Clarke Wright Algorithm.
 * 
 */

package CW;


public class SavingsNode implements Comparable<SavingsNode>{
	
	Customer ci;
	Customer cj;
	double saving;

	public SavingsNode(Customer ci, Customer cj, double saving) {
		
		this.ci = ci;
		this.cj = cj;
		this.saving = saving;
	}

	//Takes in a SavingsNode
	//If the passed in savings node has less savings than this then return -1.
	//If passed in savings node has more savings than this node then return 1.
	//If the savings are equal return 0;
	@Override
	public int compareTo(SavingsNode o) {
		if(o.saving < this.saving) {
			return -1;
		}
		if(o.saving > this.saving) {
			return 1;
		}
		
		return 0;
	}
	
	//Getter for savings.
	public double getSaving() {
		return this.saving;
	}

}
