/*
 * Created by: Jordan Stephano Gray
 * University: Edinburgh Napier University
 * Matric: 40087220
 * Year: 3
 * Module: Algorithms and Data Structures
 * Email: graybostephano@gmail.com
 * Project Purpose: Assign with task of implementing 
 * an algorithm to solve vehicle routing problems.
 * Algorithm Used: Clarke Wright Algorithm.
 * 
 */

package CW;

import java.util.*;
import java.io.*;

public class VRSolution {
	public VRProblem prob;
	public List<List<Customer>> soln;
	public List<Route> mySoln;			//Initialise My Solution as list of Routes(Linked List)

	public VRSolution(VRProblem problem) {
		this.prob = problem;
	}

	// The dumb solver adds one route per customer
	public void oneRoutePerCustomerSolution() {
		this.soln = new ArrayList<List<Customer>>();
		for (Customer c : prob.customers) {
			ArrayList<Customer> route = new ArrayList<Customer>();
			route.add(c);
			soln.add(route);
		}
	}// END oneRoutePerCutomerSolution METHOD.

	// Students should implement another solution
	/*
	 * Clarke Wright algorithm. This algorithm has these steps. 1: Get distance
	 * between customer node i and depot node. 2: Get distance between customer
	 * node j and depot node. 3: Get the savings (customer i to customer j) 4:
	 * Calculate savings by doing depot to ci + depot to cj - ci to cj. 5: For
	 * the new savings nodes determine whether the routes are on the route. 6:
	 * If only one customer is on the route the see if there is the capacity add
	 * to the route.
	 */
	public void clarkeWright() {

		// The solution, a list of a list type routes.
		// Routes object is a Singly LinkedList
		this.mySoln = new ArrayList<Route>();
		// Create a List containing SavingsNodes.
		ArrayList<SavingsNode> savingsList = new ArrayList<SavingsNode>();

		// **STEP 1: CALCULATE SAVINGS**

		// For all the customers in the problem do this.
		// Nested for loop to go through each customer twice.
		for (int i = 0; i < prob.customers.size(); i++) {
			for (int j = i + 1; j < prob.customers.size(); j++) {

				// Works out the savings.
				// Adds both depot to customer distances together and
				// subtracts customer to customer distance from it.
				double saving = (prob.depot.distance(prob.customers.get(i)) + prob.depot.distance(prob.customers.get(j))
						- prob.customers.get(i).distance(prob.customers.get(j)));
				// Add the distances and saving to the savings list
				savingsList.add(new SavingsNode(prob.customers.get(i), prob.customers.get(j), saving));

				System.out.println(prob.depot);
				System.out.println(prob.customers.get(i));
				System.out.println(prob.customers.get(j));

			}
		} // End for

		// Sort the list of savings nodes. **COMPARE REQUIREMENTS???**
		// Collections.sort(savingsList);
		Collections.sort(savingsList, new Comparator<SavingsNode>() {
			public int compare(SavingsNode c1, SavingsNode c2) {
				return Double.compare(c1.getSaving(), c2.getSaving());
			}
		});
		//Sort savings from highest to lowest
		Collections.reverse(savingsList);

		// Print savingsList in console.
		for (SavingsNode s : savingsList) {
			// Prints saving attributes
			System.out.println(s.saving);
		}

		// **STEP 2: MERGE ROUTES**

		// For every SavingsNode in List savings.
		for (SavingsNode sn : savingsList) {

			// Neither customer in a route already.
			if (!checkInRoute(this.mySoln, sn.ci) && !checkInRoute(this.mySoln, sn.cj)) {
				// The demand of customer is less than the capacity of
				// truck(depot).
				if (sn.ci.c + sn.cj.c <= prob.depot.c) {
					// Create a new Route object and add both customers to it.
					Route newRoute = new Route();
					newRoute.addToStart(sn.ci);
					newRoute.add(sn.cj);

					// Add route to the solution
					this.mySoln.add(newRoute);
				}

			} // End if
			// Find a route that ends at 'from'.
			else {
				// If route doesn't contain the 'to' customer
				if (!checkInRoute(this.mySoln, sn.cj)) {
					// For every route in the route array
					for (Route r : this.mySoln) {
						// If the last element was the 'from' customer
						if (r.get(r.size()) == sn.ci) {
							// If the route has capacity then add 'to'
							// customer to route
							if (r.getCapacity() + sn.cj.c <= prob.depot.c) {
								r.add(sn.cj);
								break;
							}

						}

					}

				}
				// Find route that starts at 'to'
				if (!checkInRoute(this.mySoln, sn.ci)) {
					// For every route object stored in solution
					for (Route r : this.mySoln) {
						// If last element in route object is customer j 'to'
						if (r.get(r.size()) == sn.cj) {
							// If route capacity - customer requirements >= 0
							if (r.getCapacity() + sn.ci.c <= prob.depot.c) {
								r.addToStart(sn.ci); // Add customer i to start
														// of route.
								break;
							} // End if

						} // End if

					} // End for

				} // End if

			} // End else

			/*
			 * Check if two routes can be merged.
			 */
			// Create a route object merged and assign null.
			Route merged = null;
			// For loop for every routeX
			for (Route routeX : this.mySoln) {
				// If merged has a value assigned.
				if (merged != null)
					break;
				// If customer i is last element in the delivery
				if (routeX.getTail() == sn.cj) {
					// For every route(2) in list of all routes (soln).
					for (Route routeY : this.mySoln) {
						// If first element in this route is = customer j
						if (routeY.get(1) == sn.ci) { // *************
							// if routeX isn't also routeY
							if (routeX != routeY) {
								// If routex and routey's leftover demands meet
								// capacity of truck
								if ((routeX.getCapacity() + routeY.getCapacity()) <= prob.depot.c) { // ***DEPOT
																										// CAP?

									// This appends each customer in routeY to
									// routeX
									routeX.merge(routeY);
									merged = routeY;

									break;
								} // END if

							} // END if

						} // END if

					} // END for

				} // END if

			} // END for

			// Delete routeY
			if (merged != null)
				this.mySoln.remove(merged);

		} // END for


		// Allocate remaining customers to own routes.
		// for every customer in the problem left over
		for (int i = 0; i < prob.customers.size(); i++) {
			// for (Customer pc : prob.customers) { //****************
			// If customer is not in any route.
			if (!checkInRoute(this.mySoln, prob.customers.get(i))) { // **************
				// Create new route and add only that customer to the route
				Route r = new Route();
				r.addToStart(prob.customers.get(i));
				this.mySoln.add(r);
			}
		}//END for

		// Prints every route in my solution
		for (Route route : this.mySoln) {

			System.out.println("");
			for (int i = 1; i <= route.size(); i++) {
				System.out.println(route.get(i));
			}

		}//END for

	} // END METHOD ClarkWright

	// Check if a customer is in a route in my solution.
	public boolean checkInRoute(List<Route> theSoln, Customer theCust) {
		// Initialise boolean
		boolean isInRoute = false;
		// For every route in the solution
		for (Route r : theSoln) {
			if (r.contains(theCust)) {
				isInRoute = true;
			}

		}

		// Return boolean
		return isInRoute;
	}

	// Calculate the total journey
	public double solnCost() {

		double cost = 0;
		for (Route route : this.mySoln) {
			Customer prev = this.prob.depot;
			for (int i = 1; i <= route.size(); i++) {
				Customer cust = route.get(i);
				cost += prev.distance(cust);
				prev = cust;
			}
			// Add cost of returning to depot
			cost += prev.distance(this.prob.depot);
		}
		return cost;
	}

	public Boolean verify() {
		
		// Check that no route exceeds capacity
		Boolean okSoFar = true;
		for (Route route : this.mySoln) {
			// Start the spare capacity at
			int total = 0;
			// For every element in the route
			for (int i = 1; i <= route.size(); i++) {
				// create new customer which = to i.
				Customer cust = route.get(i);
				// Set total to customer req.
				total += cust.c;
			}
			// If total goes over depot cap
			if (total > prob.depot.c) {
				System.out.printf("********FAIL Route starting %s is over capacity %d\n", route.get(0), total);
				okSoFar = false;
			}
		}
		// Check that we keep the customer satisfied
		// Check that every customer is visited and the correct amount is picked
		// up
		Map<String, Integer> reqd = new HashMap<String, Integer>();
		for (Customer c : this.prob.customers) {
			String address = String.format("%fx%f", c.x, c.y);
			reqd.put(address, c.c);
		}
		for (Route route : this.mySoln) {
			for (int i = 1; i <= route.size(); i++) {
				// Create customer and assign to customer i in route.
				Customer cust = route.get(i);

				String address = String.format("%fx%f", cust.x, cust.y);
				if (reqd.containsKey(address))
					reqd.put(address, reqd.get(address) - cust.c);
				else
					System.out.printf("********FAIL no customer at %s\n", address);
			}
		}
		for (String address : reqd.keySet())
			if (reqd.get(address) != 0) {
				System.out.printf("********FAIL Customer at %s has %d left over\n", address, reqd.get(address));
				okSoFar = false;
			}
		return okSoFar;

	}

	public void readIn(String filename) throws Exception {

		BufferedReader br = new BufferedReader(new FileReader(filename));
		String s;
		this.mySoln = new ArrayList<Route>();
		while ((s = br.readLine()) != null) {
			Route route = new Route();
			String[] xycTriple = s.split(",");
			for (int i = 0; i < xycTriple.length; i += 3)
				route.add(new Customer((int) Double.parseDouble(xycTriple[i]),
						(int) Double.parseDouble(xycTriple[i + 1]), (int) Double.parseDouble(xycTriple[i + 2])));
			this.mySoln.add(route);
		}
		br.close();

	}

	public void writeSVG(String probFilename, String solnFilename) throws Exception {

		String[] colors = "chocolate cornflowerblue crimson cyan darkblue darkcyan darkgoldenrod".split(" ");
		int colIndex = 0;
		String hdr = "<?xml version='1.0'?>\n"
				+ "<!DOCTYPE svg PUBLIC '-//W3C//DTD SVG 1.1//EN' '../../svg11-flat.dtd'>\n"
				+ "<svg width='8cm' height='8cm' viewBox='0 0 500 500' xmlns='http://www.w3.org/2000/svg' version='1.1'>\n";
		String ftr = "</svg>";
		StringBuffer psb = new StringBuffer();
		StringBuffer ssb = new StringBuffer();
		psb.append(hdr);
		ssb.append(hdr);
		for (Route route : this.mySoln) {
			ssb.append(String.format("<path d='M%s %s ", this.prob.depot.x, this.prob.depot.y));
			for (int i = 1; i <= route.size(); i++) {
				Customer cust = route.get(i);
				ssb.append(String.format("L%s %s", cust.x, cust.y));
			}
			ssb.append(String.format("z' stroke='%s' fill='none' stroke-width='2'/>\n",
					colors[colIndex++ % colors.length]));
		}
		for (Customer c : this.prob.customers) {
			String disk = String.format("<g transform='translate(%.0f,%.0f)'>"
					+ "<circle cx='0' cy='0' r='%d' fill='pink' stroke='black' stroke-width='1'/>"
					+ "<text text-anchor='middle' y='5'>%d</text>" + "</g>\n", c.x, c.y, 10, c.c);
			psb.append(disk);
			ssb.append(disk);
		}
		String disk = String.format(
				"<g transform='translate(%.0f,%.0f)'>"
						+ "<circle cx='0' cy='0' r='%d' fill='pink' stroke='black' stroke-width='1'/>"
						+ "<text text-anchor='middle' y='5'>%s</text>" + "</g>\n",
				this.prob.depot.x, this.prob.depot.y, 20, "D");
		psb.append(disk);
		ssb.append(disk);
		psb.append(ftr);
		ssb.append(ftr);
		PrintStream ppw = new PrintStream(new FileOutputStream(probFilename));
		PrintStream spw = new PrintStream(new FileOutputStream(solnFilename));
		ppw.append(psb);
		spw.append(ssb);
		ppw.close();
		spw.close();
	}

	public void writeOut(String filename) throws Exception {

		PrintStream ps = new PrintStream(filename);
		for (Route route : this.mySoln) {
			boolean firstOne = true;
			for (int i = 1; i <= route.size(); i++) {
				Customer cust = route.get(i);
				if (!firstOne)
					ps.print(",");
				firstOne = false;
				ps.printf("%f,%f,%d", cust.x, cust.y, cust.c);
			}
			ps.println();
		}
		ps.close();
	}
}
