/*
 * Created by: Jordan Stephano Gray
 * University: Edinburgh Napier University
 * Matric: 40087220
 * Year: 3
 * Module: Algorithms and Data Structures
 * Email: graybostephano@gmail.com
 * Project Purpose: Assign with task of implementing 
 * an algorithm to solve vehicle routing problems.
 * Algorithm Used: Clarke Wright Algorithm.
 * 
 */

package CW;

public class Main {

	public static void main(String[] args) throws Exception {

		// Load problem.
		VRProblem p = new VRProblem("rand00050prob.csv");

		// Create blank solution.
		VRSolution s = new VRSolution(p);

		// Use existing problem solver to build solution.
		// s.oneRoutePerCustomerSolution();

		// Measure the speed of the solver.
		// Time started
		double startTime = System.currentTimeMillis();

		// Use existing problem solver to build a solution.
		// s.oneRoutePerCustomerSolution();

		// Run my solution
		s.clarkeWright();

		// Time finished.
		double endTime = System.currentTimeMillis();

		// Print out time taken.
		System.out.println("Time taken: " + (endTime - startTime));

		// Print out cost of the solution
		System.out.println("Cost: " + s.solnCost());

		// Save the solution file for verification
		s.writeOut("MySolution.csv");

		// Create pictures of the problem and the solution.
		s.writeSVG("rand00050prob.svg", "MyPictureSolution.svg");

	}

}
