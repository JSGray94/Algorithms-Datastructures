/*
 * Created by: Jordan Stephano Gray
 * University: Edinburgh Napier University
 * Matric: 40087220
 * Year: 3
 * Module: Algorithms and Data Structures
 * Email: graybostephano@gmail.com
 * Project Purpose: Assign with task of implementing 
 * an algorithm to solve vehicle routing problems.
 * Algorithm Used: Clarke Wright Algorithm.
 * 
 */

package CW;

import java.awt.geom.Point2D;


public class Customer extends Point2D.Double{

	// Requirements of the customer (number to be delivered)
	public int c;
	public Customer(int x, int y, int requirement){
		this.x = x;
		this.y = y;
		this.c = requirement;
	}
	
}
